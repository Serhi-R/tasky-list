import Home from './home/page';

export default function Index() {
    return (
        <div className="grid justify-items-center font-[family-name:var(--font-geist-sans)]">
            <Home />
        </div>
    );
}
