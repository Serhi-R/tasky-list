import Footer from '../../src/components/Footer/Footer';
import Header from '../../src/components/Header/Header';

export default function Home() {
    return (
        <>
            <Header />
            
            <Footer />
        </>
    );
}
